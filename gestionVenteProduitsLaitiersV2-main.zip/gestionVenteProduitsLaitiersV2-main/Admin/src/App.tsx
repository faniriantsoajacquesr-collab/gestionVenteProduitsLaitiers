import { useState } from 'react'
import Sidebar from './components/UI/Sidebar'
import Dashboard from './pages/Dashboard'
import Products from './pages/Products'
import Clients from './pages/Clients'
import Orders from './pages/Orders'
import { Toaster } from 'react-hot-toast'

type PageId = 'dashboard' | 'products' | 'clients' | 'orders'

const pages: Record<PageId, React.ComponentType> = {
  dashboard: Dashboard,
  products: Products,
  clients: Clients,
  orders: Orders,
}

function App() {
  const [activePage, setActivePage] = useState<PageId>('dashboard')
  const PageComponent = pages[activePage]

  return (
    <div className="min-h-screen bg-background text-on-background">
      <Toaster position="top-right" />
      <Sidebar activePage={activePage} setActivePage={setActivePage} />
      <main className="transition-all duration-300 ml-64">
        <div className="p-8">
          <PageComponent />
        </div>
      </main>
    </div>
  )
}

export default App
