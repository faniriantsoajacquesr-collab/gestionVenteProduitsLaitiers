import { Home, Package, Users, ShoppingCart, LogOut, ChevronLeft, ChevronRight } from 'lucide-react'
import { useState } from 'react'

type PageId = 'dashboard' | 'products' | 'clients' | 'orders'

const menuItems = [
  { id: 'dashboard' as PageId, label: 'Tableau de bord', icon: Home },
  { id: 'products' as PageId, label: 'Produits', icon: Package },
  { id: 'clients' as PageId, label: 'Clients', icon: Users },
  { id: 'orders' as PageId, label: 'Commandes', icon: ShoppingCart },
]

interface SidebarProps {
  activePage: PageId
  setActivePage: (page: PageId) => void
}

export default function Sidebar({ activePage, setActivePage }: SidebarProps) {
  const [collapsed, setCollapsed] = useState(false)

  return (
    <aside 
      className={`fixed left-0 top-0 h-screen bg-surface-container-lowest border-r border-outline-variant transition-all duration-300 z-40 ${
        collapsed ? 'w-20' : 'w-64'
      }`}
    >
      <div className="flex flex-col h-full">
        <div className={`h-16 flex items-center border-b border-outline-variant ${collapsed ? 'justify-center px-2' : 'px-6'}`}>
          {!collapsed && (
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center">
                <span className="text-on-primary font-bold text-lg">DP</span>
              </div>
              <div>
                <h1 className="font-bold text-on-surface text-sm">Dairy Products</h1>
                <p className="text-xs text-on-surface-variant">Admin Panel</p>
              </div>
            </div>
          )}
          {collapsed && (
            <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center">
              <span className="text-on-primary font-bold text-lg">DP</span>
            </div>
          )}
        </div>

        <nav className="flex-1 py-4 px-3 space-y-1 overflow-y-auto custom-scrollbar">
          {menuItems.map((item) => {
            const Icon = item.icon
            const isActive = activePage === item.id
            
            return (
              <button
                key={item.id}
                onClick={() => setActivePage(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-200 ${
                  isActive 
                    ? 'bg-primary text-on-primary shadow-lg shadow-primary/25' 
                    : 'text-on-surface-variant hover:bg-surface-container hover:text-on-surface'
                } ${collapsed ? 'justify-center' : ''}`}
              >
                <Icon className="w-5 h-5 flex-shrink-0" />
                {!collapsed && <span className="font-medium text-sm">{item.label}</span>}
              </button>
            )
          })}
        </nav>

        <div className="p-3 border-t border-outline-variant">
          <button className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-error transition-all duration-200 hover:bg-error/10 ${collapsed ? 'justify-center' : ''}`}>
            <LogOut className="w-5 h-5 flex-shrink-0" />
            {!collapsed && <span className="font-medium text-sm">Déconnexion</span>}
          </button>
        </div>

        <button
          onClick={() => setCollapsed(!collapsed)}
          className="absolute -right-3 top-20 w-6 h-6 bg-surface-container-lowest border border-outline-variant rounded-full flex items-center justify-center shadow-md hover:bg-surface-container transition-colors"
        >
          {collapsed ? (
            <ChevronRight className="w-4 h-4 text-on-surface-variant" />
          ) : (
            <ChevronLeft className="w-4 h-4 text-on-surface-variant" />
          )}
        </button>
      </div>
    </aside>
  )
}
