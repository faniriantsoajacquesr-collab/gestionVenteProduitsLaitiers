import { useState, useEffect } from 'react'
import { Search, User } from 'lucide-react'
import { api } from '../lib/api'

interface Client {
  id: string
  first_name: string
  last_name: string
  phone_number: string
  delivery_address: string
  role: string
  updated_at: string
}

export default function Clients() {
  const [clients, setClients] = useState<Client[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [search, setSearch] = useState('')

  useEffect(() => { loadClients() }, [])

  const loadClients = async () => {
    try {
      setLoading(true)
      const data = await api.clients.getAll()
      setClients(Array.isArray(data) ? data : [])
      setError(null)
    } catch (err) { setError(err instanceof Error ? err.message : 'Erreur de chargement') }
    finally { setLoading(false) }
  }

  const filteredClients = clients.filter(client => {
    const name = `${client.first_name || ''} ${client.last_name || ''}`.toLowerCase()
    return name.includes(search.toLowerCase())
  })

  const getRoleBadge = (role: string) => {
    const badges: Record<string, string> = { 'admin': 'bg-purple-100 text-purple-700', 'client': 'bg-blue-100 text-blue-700' }
    return badges[role] || 'bg-gray-100 text-gray-700'
  }

  const getFullName = (client: Client) => `${client.first_name || ''} ${client.last_name || ''}`.trim() || 'Client'

  const formatDate = (dateStr: string) => {
    if (!dateStr) return ''
    return new Date(dateStr).toLocaleDateString('fr-FR')
  }

  if (loading) return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-12 w-12 border-4 border-primary border-t-transparent"></div></div>

  return (
    <div className="space-y-6">
      {error && <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl">{error}</div>}
      <div className="flex items-center justify-between">
        <div><h1 className="text-2xl font-bold text-on-surface">Liste des clients</h1><p className="text-on-surface-variant mt-1">{clients.length} client(s)</p></div>
      </div>
      <div className="flex flex-wrap items-center gap-4">
        <div className="relative flex-1 min-w-[200px]"><Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-on-surface-variant" /><input type="text" placeholder="Rechercher..." value={search} onChange={(e) => setSearch(e.target.value)} className="w-full pl-10 pr-4 py-2.5 bg-surface-container-lowest border border-outline-variant rounded-xl text-on-surface" /></div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredClients.map((client) => (
          <div key={client.id} className="bg-surface-container-lowest rounded-2xl border border-outline-variant p-5 shadow-sm">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                <span className="text-primary font-bold text-lg">{getFullName(client).split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()}</span>
              </div>
              <div>
                <h3 className="font-bold text-on-surface">{getFullName(client)}</h3>
                <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${getRoleBadge(client.role)}`}>{client.role}</span>
              </div>
            </div>
            <div className="space-y-2 text-sm">
              <p className="text-on-surface-variant">{client.phone_number || '-'}</p>
              <p className="text-on-surface-variant truncate">{client.delivery_address || '-'}</p>
              <p className="text-xs text-on-surface-variant">Inscrit: {formatDate(client.updated_at)}</p>
            </div>
          </div>
        ))}
      </div>
      {filteredClients.length === 0 && <div className="text-center py-12"><User className="w-16 h-16 text-on-surface-variant mx-auto mb-4 opacity-50" /><p className="text-on-surface-variant">Aucun client trouvé</p></div>}
    </div>
  )
}
