import { useState, useEffect } from 'react'
import { Eye, X, Package } from 'lucide-react'
import { api } from '../lib/api'

interface Order {
  id: string
  user_id: string
  delivery_address: string
  contact_phone: string
  total_amount: number
  status: string
  created_at: string
}

const statusOptions = ['pending', 'processing', 'delivered', 'cancelled']

export default function Orders() {
  const [orders, setOrders] = useState<Order[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [search, setSearch] = useState('')
  const [filterStatus, setFilterStatus] = useState('Tous')
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null)

  useEffect(() => { loadOrders() }, [])

  const loadOrders = async () => {
    try {
      setLoading(true)
      const data = await api.orders.getAll()
      setOrders(data)
      setError(null)
    } catch (err) { setError((err as Error).message) }
    finally { setLoading(false) }
  }

  const filteredOrders = orders.filter(order => {
    const matchesSearch = order.user_id?.toLowerCase().includes(search.toLowerCase()) || order.delivery_address?.toLowerCase().includes(search.toLowerCase())
    const matchesStatus = filterStatus === 'Tous' || order.status === filterStatus
    return matchesSearch && matchesStatus
  })

  const handleUpdateStatus = async (id: string, status: string) => {
    try {
      await api.orders.updateStatus(id, status)
      loadOrders()
      setSelectedOrder(null)
    } catch (err) { setError((err as Error).message) }
  }

  const getStatusBadge = (status: string) => {
    const badges: Record<string, string> = {
      'pending': 'bg-yellow-100 text-yellow-700',
      'processing': 'bg-blue-100 text-blue-700',
      'shipped': 'bg-purple-100 text-purple-700',
      'delivered': 'bg-green-100 text-green-700',
      'cancelled': 'bg-red-100 text-red-700'
    }
    return badges[status] || 'bg-gray-100 text-gray-700'
  }

  const getStatusLabel = (status: string) => {
    const labels: Record<string, string> = {
      'pending': 'En attente',
      'processing': 'En cours',
      'shipped': 'Expédié',
      'delivered': 'Livré',
      'cancelled': 'Annulé'
    }
    return labels[status] || status
  }

  const formatDate = (dateStr: string) => {
    if (!dateStr) return '-'
    return new Date(dateStr).toLocaleDateString('fr-FR')
  }

  if (loading) return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-12 w-12 border-4 border-primary border-t-transparent"></div></div>

  return (
    <div className="space-y-6">
      {error && <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl">{error}</div>}
      <div className="flex items-center justify-between">
        <div><h1 className="text-2xl font-bold text-on-surface">Gestion des commandes</h1><p className="text-on-surface-variant mt-1">{orders.length} commande(s)</p></div>
      </div>
      <div className="flex flex-wrap items-center gap-4">
        <input type="text" placeholder="Rechercher..." value={search} onChange={(e) => setSearch(e.target.value)} className="flex-1 px-4 py-2.5 bg-surface-container-lowest border border-outline-variant rounded-xl text-on-surface" />
        <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)} className="px-4 py-2.5 bg-surface-container-lowest border border-outline-variant rounded-xl text-on-surface">
          <option value="Tous">Tous</option>
          <option value="pending">En attente</option>
          <option value="processing">En cours</option>
          <option value="delivered">Livré</option>
          <option value="cancelled">Annulé</option>
        </select>
      </div>
      <div className="bg-surface-container-lowest rounded-2xl border border-outline-variant shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead><tr className="border-b border-outline-variant bg-surface-container">
              <th className="text-left px-6 py-4 text-xs font-semibold text-on-surface-variant uppercase">ID</th>
              <th className="text-left px-6 py-4 text-xs font-semibold text-on-surface-variant uppercase">Client</th>
              <th className="text-left px-6 py-4 text-xs font-semibold text-on-surface-variant uppercase">Total</th>
              <th className="text-left px-6 py-4 text-xs font-semibold text-on-surface-variant uppercase">Date</th>
              <th className="text-left px-6 py-4 text-xs font-semibold text-on-surface-variant uppercase">Statut</th>
              <th className="text-right px-6 py-4 text-xs font-semibold text-on-surface-variant uppercase">Actions</th>
            </tr></thead>
            <tbody className="divide-y divide-outline-variant">
              {filteredOrders.map((order) => (
                <tr key={order.id} className="hover:bg-surface-container transition-colors">
                  <td className="px-6 py-4"><span className="font-medium text-primary text-sm">{order.id?.slice(0, 8)}...</span></td>
                  <td className="px-6 py-4"><span className="text-on-surface text-sm">{order.delivery_address?.slice(0, 30)}...</span></td>
                  <td className="px-6 py-4 font-bold text-on-surface">{order.total_amount?.toLocaleString()} Ar</td>
                  <td className="px-6 py-4 text-on-surface-variant text-sm">{formatDate(order.created_at)}</td>
                  <td className="px-6 py-4"><span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusBadge(order.status)}`}>{getStatusLabel(order.status)}</span></td>
                  <td className="px-6 py-4"><div className="flex items-center justify-end gap-2"><button onClick={() => setSelectedOrder(order)} className="p-2 hover:bg-surface-container rounded-lg transition-colors"><Eye className="w-4 h-4 text-primary" /></button></div></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      {filteredOrders.length === 0 && <div className="text-center py-12"><Package className="w-16 h-16 text-on-surface-variant mx-auto mb-4 opacity-50" /><p className="text-on-surface-variant">Aucune commande trouvée</p></div>}
      {selectedOrder && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-surface-container-lowest rounded-2xl w-full max-w-lg shadow-2xl">
            <div className="flex items-center justify-between p-6 border-b border-outline-variant"><h2 className="text-xl font-bold text-on-surface"> Commande</h2><button onClick={() => setSelectedOrder(null)} className="p-2 hover:bg-surface-container rounded-lg transition-colors"><X className="w-5 h-5 text-on-surface-variant" /></button></div>
            <div className="p-6 space-y-4">
              <div><p className="text-xs text-on-surface-variant uppercase mb-1">Adresse</p><p className="text-on-surface">{selectedOrder.delivery_address}</p></div>
              <div><p className="text-xs text-on-surface-variant uppercase mb-1">Téléphone</p><p className="text-on-surface">{selectedOrder.contact_phone || '-'}</p></div>
              <div className="grid grid-cols-2 gap-4">
                <div><p className="text-xs text-on-surface-variant uppercase mb-1">Date</p><p className="text-on-surface">{formatDate(selectedOrder.created_at)}</p></div>
                <div><p className="text-xs text-on-surface-variant uppercase mb-1">Total</p><p className="text-2xl font-bold text-primary">{selectedOrder.total_amount?.toLocaleString()} Ar</p></div>
              </div>
            </div>
            <div className="p-6 border-t border-outline-variant flex gap-3 flex-wrap">
              <button onClick={() => handleUpdateStatus(selectedOrder.id, 'processing')} className="px-4 py-2.5 bg-blue-600 text-white rounded-xl font-medium hover:bg-blue-700">En cours</button>
              <button onClick={() => handleUpdateStatus(selectedOrder.id, 'delivered')} className="px-4 py-2.5 bg-green-600 text-white rounded-xl font-medium hover:bg-green-700">Livré</button>
              <button onClick={() => handleUpdateStatus(selectedOrder.id, 'cancelled')} className="px-4 py-2.5 border border-outline-variant rounded-xl text-error font-medium hover:bg-error/10">Annuler</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
