const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000'

const apiRequest = async (endpoint, options = {}) => {
  const headers = {
    'Content-Type': 'application/json',
    ...options.headers,
  }

  console.log(`[API Request] ${options.method || 'GET'} ${API_URL}${endpoint}`);
  const response = await fetch(`${API_URL}${endpoint}`, {
    ...options,
    headers,
  })

  if (!response.ok) {
    const error = await response.json().catch(() => ({ error: 'Request failed' }))
    throw new Error(error.error || 'Request failed')
  }

  return response.json()
}

export const api = {
  produits: {
    getAll: async () => {
      return apiRequest('/api/admin/products')
    },
    getById: async (id: string) => {
      return apiRequest(`/api/admin/products/${id}`)
    },
    create: async (product: Record<string, unknown>) => {
      return apiRequest('/api/admin/products', {
        method: 'POST',
        body: JSON.stringify(product),
      })
    },
    update: async (id: string, updates: Record<string, unknown>) => {
      return apiRequest(`/api/admin/products/${id}`, {
        method: 'PUT',
        body: JSON.stringify(updates),
      })
    },
    delete: async (id: string) => {
      return apiRequest(`/api/admin/products/${id}`, {
        method: 'DELETE',
      })
    },
  },

  clients: {
    getAll: async () => {
      return apiRequest('/api/admin/users')
    },
    getById: async (id: string) => {
      return apiRequest(`/api/admin/users/${id}`)
    },
    create: async (clientData: Record<string, unknown>) => {
      return apiRequest('/api/admin/users', {
        method: 'POST',
        body: JSON.stringify(clientData),
      })
    },
    update: async (id: string, updates: Record<string, unknown>) => {
      return apiRequest(`/api/admin/users/${id}`, {
        method: 'PUT',
        body: JSON.stringify(updates),
      })
    },
    delete: async (id: string) => {
      return apiRequest(`/api/admin/users/${id}`, {
        method: 'DELETE',
      })
    },
  },

  orders: {
    getAll: async () => {
      return apiRequest('/api/admin/orders')
    },
    updateStatus: async (id: string, status: string) => {
      return apiRequest(`/api/admin/orders/${id}/status`, {
        method: 'PUT',
        body: JSON.stringify({ status }),
      })
    },
  },

  images: {
    upload: async (file: File, productId?: string) => {
      const formData = new FormData()
      formData.append('image', file)
      if (productId) formData.append('productId', productId)

      const response = await fetch(`${API_URL}/api/admin/images/upload`, {
        method: 'POST',
        body: formData,
      })

      if (!response.ok) {
        const error = await response.json().catch(() => ({ error: 'Upload failed' }))
        throw new Error(error.error || 'Upload failed')
      }

      return response.json()
    },
  },
}
