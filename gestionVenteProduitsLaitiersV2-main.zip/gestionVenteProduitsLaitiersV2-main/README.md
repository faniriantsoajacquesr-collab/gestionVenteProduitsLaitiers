# 🥛 Gestion de Vente de Produits Laitiers (v2)

Ce projet est une solution complète pour la gestion et la vente de produits laitiers. Il se compose de trois parties principales : un serveur (Backend), une interface client (E-commerce) et un panneau d'administration.

---

## 🛠️ Installation et Configuration

Pour faire fonctionner ce projet sur votre machine locale, suivez ces étapes :

### 1. Prérequis
- **Node.js** (v18 ou supérieur) installé sur votre PC.
- Un compte **Supabase** (ou les clés API fournies par l'administrateur).

### 2. Installation des Modules
Ce projet contient 3 dossiers distincts. Vous devez installer les dépendances dans chaque dossier.

#### 📁 Backend (Serveur)
Ouvrez votre terminal dans le dossier `Server` :
```bash
cd Server
npm install
```
*Note : Assurez-vous d'avoir votre fichier `.env` dans `Server/config/.env`.*

#### 📁 Frontend (Client)
Ouvrez votre terminal dans le dossier `Client` :
```bash
cd Client
npm install
```

#### 📁 Admin Panel (Gestion)
Ouvrez votre terminal dans le dossier `Admin` :
```bash
cd Admin
npm install
```

---

## 🚀 Lancement du Projet

Pour démarrer l'application complète, vous devrez lancer 3 terminaux séparés :

1. **Terminal 1 (Serveur) :** `cd Server && npm run dev` (Port 5000)
2. **Terminal 2 (Client) :** `cd Client && npm run dev` (Port 5173)
3. **Terminal 3 (Admin) :** `cd Admin && npm run dev` (Port 5174)

---

## 📄 Structure du Projet
- **`/Server`** : API Node.js/Express connectée à Supabase.
- **`/Client`** : Interface e-commerce pour les clients.
- **`/Admin`** : Panneau de gestion des produits, commandes et utilisateurs.
- **`/DB`** : Schémas et scripts SQL de la base de données.

---

