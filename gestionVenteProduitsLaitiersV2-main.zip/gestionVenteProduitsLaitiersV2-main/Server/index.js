import dotenv from 'dotenv';
// Load environment variables immediately from the correct path
dotenv.config({ path: './config/.env' });

import express from 'express';
import cors from 'cors';
import morgan from 'morgan'; // For logging requests in the terminal

// Import Routers
import authRoutes from './client/routes/authRoutes.js';
import productRoutes from './client/routes/productRoutes.js';
import cartRoutes from './client/routes/cartRoutes.js';
import orderRoutes from './client/routes/orderRoutes.js';
import userRoutes from './client/routes/userRoutes.js';

// Import Admin Routers
import adminProductRoutes from './admin/routes/productRoutes.js';
import adminUserRoutes from './admin/routes/userRoutes.js';
import adminOrderRoutes from './admin/routes/orderRoutes.js';

import { supabase } from './config/supabase.js';

const app = express();

// --- 1. GLOBAL MIDDLEWARE ---

const allowedOrigins = [
  process.env.CLIENT_URL || 'http://localhost:5173',
  process.env.ADMIN_URL || 'http://localhost:5174'
];

app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  
  // Handle preflight requests
  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }
  next();
});

// Parse incoming JSON requests
app.use(express.json());

// GLOBAL DEBUG LOGGER
app.use((req, res, next) => {
  console.log(`[GLOBAL] ${req.method} ${req.url}`);
  next();
});

// Global middleware to attach Supabase client to the request object
app.use((req, res, next) => {
  req.supabase = supabase;
  next();
});

// --- 2. MOUNT ROUTES ---

// Auth: Login, Register, Profile Me
app.use('/api/auth', authRoutes);

// Products: Catalog, Details, Admin CRUD
app.use('/api/products', productRoutes);

// Cart: Add to bag, View bag
app.use('/api/cart', cartRoutes);

// Orders: Checkout and History
app.use('/api/orders', orderRoutes);

// Users: Admin management and Profile updates
app.use('/api/users', userRoutes);

// --- 3. MOUNT ADMIN ROUTES ---
app.use('/api/admin/products', adminProductRoutes);
app.use('/api/admin/users', adminUserRoutes);
app.use('/api/admin/orders', adminOrderRoutes);

// --- 4. BASIC HEALTH CHECK ---
app.get('/', (req, res) => {
  res.send('API Gestion de Vente Laitière is running...');
});

// --- 4. ERROR HANDLING MIDDLEWARE ---
// Catch-all for 404
app.use((req, res, next) => {
  res.status(404).json({ error: 'Route not found' });
});

// Final error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Something went wrong on the server' });
});

// --- 5. START SERVER ---
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`
  --------------------------------------------------
   Dairy Shop Server Running
   Port: ${PORT}
   Environment: ${process.env.NODE_ENV || 'development'}
  --------------------------------------------------
  `);
});