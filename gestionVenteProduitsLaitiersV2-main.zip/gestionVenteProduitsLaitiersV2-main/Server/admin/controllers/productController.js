import { supabase } from '../../config/supabase.js';

// Utilité simple pour le slug
const slugify = (text) => {
  return text
    .toString()
    .toLowerCase()
    .trim()
    .replace(/\s+/g, '-')
    .replace(/[^\w-]+/g, '')
    .replace(/--+/g, '-');
};

// 1. LIRE TOUS LES PRODUITS
export const getProducts = async (req, res) => {
  try {
    const { data, error } = await supabase
      .from('products')
      .select(`
        *,
        product_gallery (image_url, alt_text, is_primary)
      `);

    if (error) throw error;
    res.status(200).json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// 2. LIRE UN PRODUIT PAR ID
export const getProductById = async (req, res) => {
  const { id } = req.params;
  try {
    const { data, error } = await supabase
      .from('products')
      .select('*, product_gallery (*)')
      .eq('id', id)
      .single();

    if (error || !data) return res.status(404).json({ error: 'Produit non trouvé' });
    res.status(200).json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// 3. CRÉER UN PRODUIT
export const createProduct = async (req, res) => {
  try {
    const { 
      name, price, description, unit, category, milk_type, 
      dietary_tags, stock_quantity, is_featured, imageUrl 
    } = req.body;
    
    const slug = slugify(name);

    // A. Créer le produit
    const { data: product, error: productError } = await supabase
      .from('products')
      .insert([{ 
        name, slug, price, description, unit, category, milk_type, dietary_tags, stock_quantity, is_featured 
      }])
      .select()
      .single();

    if (productError) throw productError;

    // B. Ajouter l'image si fournie
    if (imageUrl) {
      const { error: galleryError } = await supabase
        .from('product_gallery')
        .insert([{
          product_id: product.id,
          image_url: imageUrl,
          is_primary: true
        }]);
      
      if (galleryError) console.error('Gallery Error:', galleryError);
    }

    res.status(201).json(product);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

// 4. METTRE À JOUR UN PRODUIT
export const updateProduct = async (req, res) => {
  const { id } = req.params;
  const { imageUrl, ...updates } = req.body;

  try {
    if (updates.name) {
      updates.slug = slugify(updates.name);
    }

    // A. Mettre à jour les infos de base
    const { data: product, error: productError } = await supabase
      .from('products')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (productError) throw productError;

    // B. Gérer l'image
    if (imageUrl) {
      // Supprimer l'ancienne image primaire (on simplifie à une seule image pour l'admin)
      await supabase
        .from('product_gallery')
        .delete()
        .eq('product_id', id);

      // Insérer la nouvelle
      const { error: galleryError } = await supabase
        .from('product_gallery')
        .insert([{
          product_id: id,
          image_url: imageUrl,
          is_primary: true
        }]);

      if (galleryError) console.error('Gallery Update Error:', galleryError);
    }

    res.status(200).json(product);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

// 5. SUPPRIMER UN PRODUIT
export const deleteProduct = async (req, res) => {
  const { id } = req.params;
  try {
    console.log(`[Admin Product API] Tentative de suppression en cascade pour ID: ${id}`);
    
    // A. Supprimer d'abord les images associées (pour éviter les erreurs de clé étrangère)
    await supabase
      .from('product_gallery')
      .delete()
      .eq('product_id', id);

    // B. Supprimer le produit
    const { error } = await supabase
      .from('products')
      .delete()
      .eq('id', id);

    if (error) throw error;
    res.status(200).json({ message: 'Produit supprimé avec succès' });
  } catch (err) {
    console.error('Delete Controller Error:', err);
    res.status(500).json({ error: err.message });
  }
};
