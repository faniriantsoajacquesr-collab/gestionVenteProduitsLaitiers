import express from 'express';
import { 
  getAllOrders, 
  updateOrderStatus 
} from '../controllers/orderController.js';
import { protect, adminOnly } from '../middleware/authMiddleware.js';

const router = express.Router();

// Public read for development
router.get('/', getAllOrders);

// Protected status updates
router.put('/:id/status', protect, adminOnly, updateOrderStatus);

export default router;
